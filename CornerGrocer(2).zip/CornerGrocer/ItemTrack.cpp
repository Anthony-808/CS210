#include <iostream>
#include <map>
#include <string>
#include <fstream>
#include <cstdio>

using namespace std;

const int DISPLAY_WIDTH = 35; // For changing the size of display borders

// Changable display of frequency data (single-word frequency, all-words frequency, histogram). 
class OutputDisplay {
	public:
		OutputDisplay(const map<string, int>& t_itemCount);
		// functions dedicated to specific data displays
		void ShowWordCount();
		void ShowMap();
		void ShowHistogram();
		// control form of data display by selecting which function to call
		void SelectDisplay(int t_selection); 
	private:
		// frequency data
		map<string, int> itemCount;
};

// Link object to frequency data at object creation
OutputDisplay::OutputDisplay(const map<string, int>& t_itemCount) {
	itemCount = t_itemCount;
}

// display the frequency of a specific word
void OutputDisplay::ShowWordCount() {
	string word;
	int value;
	cout << "type word to count" << endl;
	cin >> word;
	// avoid program crash if word not found
	try {
		value = itemCount.at(word);
		cout << value << endl;
	}
	catch (out_of_range& excpt){
		cout << "item not listed" << endl;
	}
}

// display all words and their resepective frequencies
void OutputDisplay::ShowMap() {
	// loop through every item in frequncy map and prints out values
	for (auto const& x : itemCount) {
		cout << x.first << " " << x.second << endl;
	}
}

// display histogram of all words and their frequencies
void OutputDisplay::ShowHistogram() {
	int starCount;
	// loop through every item in frequency map and prints out values
	for (auto const& x : itemCount) {
		cout << x.first << " ";
		starCount = x.second;
		// translate frequency into a matching quantity of asterisks
		for (int i = 0; i < starCount; ++i) {
			cout << "*";
		}
		cout << endl;
	}
}

// Decide which display function to call
void OutputDisplay::SelectDisplay(int t_selection) {
	switch (t_selection) {
		case 1:
			ShowWordCount();
			break;
		case 2:
			ShowMap();
			break;
		case 3:
			ShowHistogram();
			break;
		case 4:
			exit(0);
		default:
			// should never reach this statement as input is validated
			cout << "error";
	}
}

// reads words from a file and counts their frequencies. Stores that data as a map.
void populateMap(map<string, int>& t_itemCount, string t_filename) {
	int count;
	ifstream inFS;
	string item;
	inFS.open(t_filename);

	if (inFS.is_open()) {
		// read data from file and add to map
		while (!inFS.fail()) {
			inFS >> item;
			// add word and value of 1 to map if first instance of word
			if (t_itemCount.count(item) == 0) {
				t_itemCount.emplace(item, 1);
			}
			// add 1 to value of word if it already exists in map
			else {
				count = (t_itemCount.at(item) + 1);
				t_itemCount[item] ++;
			}
		}
		// raise error if reader fails before end of file
		if (!inFS.eof()) {
			cout << "error reaching end of file";
		}
		inFS.close();
	}
	// raise error if file can't be opened
	else {
		cout << "file couldn't open";
	}
}

// get and validate user choice (display data in one of the listed forms or exit).
int getSelection() {
	string border = string(DISPLAY_WIDTH, '*');
	// prompt user for input
	cout << border << endl;
	cout << "Please make a seletion:" << endl;
	cout << endl;
	cout << "1) Display word frequency" << endl;
	cout << "2) Display frequency of all words" << endl;
	cout << "3) Display histogram" << endl;
	cout << "4) Exit" << endl;
	cout << border << endl;

	// get and validate validute user input
	char input;
	int selection;
	bool isNum;
	bool inRange = false;
	do {
		cin >> input;
		// ensure input is a number
		isNum = isdigit(input);
		if (isNum) {
			selection = input - '0';
			// esnure input is between 1 and 4
			inRange = ((selection > 0) && (selection < 5));
			if (!inRange) {
				cout << "input out of range. please select a number 1 - 4" << endl;
			}
		}
		else {
			cout << "input is not a number. please select a number 1 - 4" << endl;
		}
	// loops until valid input is given
	} while (!isNum || !inRange);
	// program only reaches this point if data is valid
	return selection;
}

// backs up data from input file to a seperate file
int backupData(const map<string, int>& t_itemCount, string t_filename) {
	ofstream outFS;

	outFS.open(t_filename);
	if (!outFS.is_open()) {
		cout << "could not open output file" << endl;
		return 1;
	}
	// loop through every data pair in map and write it to file.
	for (auto const& x : t_itemCount) {
		outFS << x.first << " " << x.second << endl;
	}
	outFS.close();
	return 0;
}

int main() {
	map<string, int> itemCount; // holds frequency data from input file.
	populateMap(itemCount, "CS210_Project_Three_Input_File.txt");
	backupData(itemCount, "frequency.dat");
	OutputDisplay newDisplay = OutputDisplay(itemCount); // object that holds and dislplays frequency data
	int selection = getSelection();
	cout << endl; // create blank line between input prompt and output
	newDisplay.SelectDisplay(selection);
	return 0;
}
